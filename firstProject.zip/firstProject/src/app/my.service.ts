import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyService {

  counter: number = 0;

  public incr(){
    this.counter++;
  }

  public decr(){
    this.counter--;
  }
  constructor() { }
}
