import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyComponent } from './my/my.component';
import { HttpClientModule } from '@angular/common/http';

import { FormsModule } from '@angular/forms';
import { App2Component } from './app2/app2.component';
import { App3Component } from './app3/app3.component';
import { MyService } from './my.service';
import { HttpDemo } from './httpdemo.component';

@NgModule({
  declarations: [
    AppComponent,
    MyComponent,
    App2Component,
    App3Component,
    HttpDemo
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent, MyComponent]
})
export class AppModule { }
