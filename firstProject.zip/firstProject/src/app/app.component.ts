import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent{
  
  title = 'xpanion';
 
  img: string = "../assets/image1.jpg";

  toggleImg() {
    this.img = this.img === "../assets/image1.jpg" ? "../assets/image2.jpg" : "../assets/image1.jpg";
  }

}
