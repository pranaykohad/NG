import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';

@Component({
  selector: 'app-app2',
  templateUrl: './app2.component.html',
  styleUrls: ['./app2.component.scss'],
  providers: [MyService]
})
export class App2Component implements OnInit {


  constructor(private myService: MyService) { }

  incr(){
    this.myService.incr();

  }

  ngOnInit() {
  }

}
