import { Component, OnInit } from '@angular/core';
import { employee } from './emp';
import { MyService } from '../my.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-my',
  templateUrl: './my.component.html',
  styleUrls: ['./my.component.scss']
})
export class MyComponent {
  showTable: boolean = false;
user: Object;
  emp: employee={
    "empNo": 1,
    "empName":"Anuj",
    "empSallary": 200000000
  };
  empList: employee[]=[];

  uid: string= "1";
  url: string = "https://reqres.in/api/users?page=2";

  addEmployee(){
      this.empList.push(this.emp);
      this.emp = new employee();
      this.showTable = true;
  }  

  delEmployee(index){
    this.empList.splice(index);
  }
  constructor(private myService: MyService, private http: HttpClient) { 
  } 

  incr(){
    this.myService.incr();
  }

  decr(){
    this.myService.decr();
  }

  getuser(){
    this.http.get(this.url).subscribe((value) => {
      this.user = value["data"];
    } 
    );
    
  }
}