export class employee{
    empNo: number;
    empName: String;
    empSallary: number;
    
}