import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';

@Component({
  selector: 'app-app3',
  templateUrl: './app3.component.html',
  styleUrls: ['./app3.component.scss'],
  providers: []
})
export class App3Component implements OnInit {

  constructor(private myService: MyService) { }

  incr(){
    this.myService.incr();
  }

  ngOnInit() {
  }

}
