import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
    selector: 'app-httpdemo',
    templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  })
  export class HttpDemo implements OnInit {

      constructor(private http: HttpClient){
      }

    

    ngOnInit(): void {
        
    }
  }